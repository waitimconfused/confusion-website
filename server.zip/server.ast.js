import * as Ast from "./Asterisk/index.js";

Ast.clearLogs();
Ast.serverside.open(1200);